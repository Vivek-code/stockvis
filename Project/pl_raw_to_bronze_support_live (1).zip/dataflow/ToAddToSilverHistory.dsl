source(output(
		BillingID as string,
		CustomerID as string,
		ContractID as string,
		BillMonth as string,
		BillAmount_GBP as string,
		PaymentStatus as string,
		DaysDelayed as string,
		penalty as string,
		PaymentRiskCategory as string
	),
	allowSchemaDrift: true,
	validateSchema: false,
	ignoreNoFilesFound: false) ~> SilverBills
source(output(
		InteractionID as string,
		CustomerID as string,
		InteractionDate as string,
		InteractionType as string,
		BronzeTimestamp as string,
		IngestionTimestamp as string
	),
	allowSchemaDrift: true,
	validateSchema: false,
	ignoreNoFilesFound: false) ~> SilverCustomerInteraction
source(output(
		UsageID as string,
		CustomerID as string,
		Month as string,
		UnitsConsumed_kWh as string,
		ingestion_timestamp as string,
		BronzeTimestamp as string,
		Month_name as string
	),
	allowSchemaDrift: true,
	validateSchema: false,
	ignoreNoFilesFound: false) ~> silverusage
SilverBills alterRow(insertIf(true())) ~> alterRow1
SilverCustomerInteraction alterRow(insertIf(true())) ~> alterRow2
silverusage alterRow(insertIf(true())) ~> alterRow3
alterRow1 sink(allowSchemaDrift: true,
	validateSchema: false,
	input(
		BillingID as string,
		CustomerID as string,
		ContractID as string,
		BillMonth as date,
		BillAmount_GBP as decimal(10,2),
		PaymentStatus as string,
		DaysDelayed as integer,
		Penalty as decimal(10,2),
		PaymentRiskCategory as string
	),
	deletable:false,
	insertable:true,
	updateable:false,
	upsertable:false,
	format: 'table',
	skipDuplicateMapInputs: true,
	skipDuplicateMapOutputs: true,
	errorHandlingOption: 'stopOnFirstError',
	mapColumn(
		BillingID,
		CustomerID,
		ContractID,
		BillMonth,
		BillAmount_GBP,
		PaymentStatus,
		DaysDelayed,
		Penalty = penalty,
		PaymentRiskCategory
	)) ~> sink1
alterRow2 sink(allowSchemaDrift: true,
	validateSchema: false,
	input(
		InteractionID as string,
		CustomerID as string,
		InteractionDate as date,
		InteractionType as string,
		BronzeTimestamp as timestamp,
		IngestionTimestamp as timestamp
	),
	deletable:false,
	insertable:true,
	updateable:false,
	upsertable:false,
	format: 'table',
	skipDuplicateMapInputs: true,
	skipDuplicateMapOutputs: true,
	errorHandlingOption: 'stopOnFirstError',
	mapColumn(
		InteractionID,
		CustomerID,
		InteractionDate,
		InteractionType,
		BronzeTimestamp,
		IngestionTimestamp
	)) ~> sink2
alterRow3 sink(allowSchemaDrift: true,
	validateSchema: false,
	input(
		UsageID as string,
		CustomerID as string,
		Month as string,
		UnitsConsumed_kWh as integer,
		ingestion_timestamp as timestamp,
		BronzeTimestamp as timestamp,
		Month_name as string
	),
	deletable:false,
	insertable:true,
	updateable:false,
	upsertable:false,
	format: 'table',
	skipDuplicateMapInputs: true,
	skipDuplicateMapOutputs: true,
	errorHandlingOption: 'stopOnFirstError',
	mapColumn(
		UsageID,
		CustomerID,
		Month,
		UnitsConsumed_kWh,
		ingestion_timestamp,
		BronzeTimestamp,
		Month_name
	)) ~> sink3