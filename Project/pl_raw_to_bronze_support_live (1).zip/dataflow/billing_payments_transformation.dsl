source(output(
		BillingID as string,
		CustomerID as string,
		ContractID as string,
		BillMonth as string,
		BillAmount_GBP as short,
		PaymentStatus as string,
		DaysDelayed as integer
	),
	allowSchemaDrift: true,
	validateSchema: false,
	ignoreNoFilesFound: false) ~> source1
source1 select(mapColumn(
		BillingID,
		CustomerID,
		ContractID,
		BillMonth,
		BillAmount_GBP,
		PaymentStatus,
		DaysDelayed
	),
	skipDuplicateMapInputs: true,
	skipDuplicateMapOutputs: true) ~> select1
split1@Valid derive(penalty = DaysDelayed*20,
		PaymentRiskCategory = iif((PaymentStatus == 'Unpaid' || PaymentStatus == 'Pending') && DaysDelayed > 15, 'High', iif(PaymentStatus == 'Paid' && toInteger(DaysDelayed) > 15, 'Medium', 'Low'))) ~> derivedColumn1
select1 split(!isNull(BillAmount_GBP) && toInteger(BillAmount_GBP) >= 0 && in(['Paid', 'Pending'], PaymentStatus) && regexMatch(BillMonth, '^[0-9]{4}-[0-9]{2}$')  && !isNull(BillingID) && regexMatch(BillingID, '^[a-zA-Z0-9]+$')  && !isNull(CustomerID) && regexMatch(CustomerID, '^[a-zA-Z0-9]+$')  && !isNull(ContractID) && regexMatch(ContractID, '^[a-zA-Z0-9]+$'),
	disjoint: false) ~> split1@(Valid, Invalid)
split1@Invalid sink(allowSchemaDrift: true,
	validateSchema: false,
	umask: 0022,
	preCommands: [],
	postCommands: [],
	skipDuplicateMapInputs: true,
	skipDuplicateMapOutputs: true) ~> quarantine
derivedColumn1 sink(allowSchemaDrift: true,
	validateSchema: false,
	umask: 0022,
	preCommands: [],
	postCommands: [],
	skipDuplicateMapInputs: true,
	skipDuplicateMapOutputs: true) ~> sliverbill