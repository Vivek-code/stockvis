source(output(
		UsageID as string,
		CustomerID as string,
		Month as string,
		UnitsConsumed_kWh as string,
		ingestion_timestamp as string
	),
	allowSchemaDrift: true,
	validateSchema: false,
	ignoreNoFilesFound: false) ~> source1
split1@valid derive(Month_name = toString(toDate(Month, 'yyyy-MM'), 'MMMM')) ~> derivedColumn1
source1 split(!isNull(UsageID) && !isNull(CustomerID) && !isNull(UnitsConsumed_kWh) && toInteger(UnitsConsumed_kWh) > 0,
	disjoint: false) ~> split1@(valid, invalid)
derivedColumn1 sink(allowSchemaDrift: true,
	validateSchema: false,
	input(
		BillingID as string,
		CustomerID as string,
		ContractID as string,
		BillMonth as string,
		BillAmount_GBP as string,
		PaymentStatus as string,
		DaysDelayed as string,
		ingestion_timestamp as string
	),
	umask: 0022,
	preCommands: [],
	postCommands: [],
	skipDuplicateMapInputs: true,
	skipDuplicateMapOutputs: true) ~> sink1
split1@invalid sink(allowSchemaDrift: true,
	validateSchema: false,
	umask: 0022,
	preCommands: [],
	postCommands: [],
	skipDuplicateMapInputs: true,
	skipDuplicateMapOutputs: true) ~> sink2