source(output(
		InteractionID as string,
		CustomerID as string,
		InteractionDate as string,
		InteractionType as string
	),
	allowSchemaDrift: true,
	validateSchema: false,
	ignoreNoFilesFound: false) ~> BronzeSource
BronzeSource split(!isNull(InteractionID) && regexMatch(InteractionID, '^[a-zA-Z0-9]+$')  && !isNull(CustomerID) && regexMatch(CustomerID, '^[a-zA-Z0-9]+$')  && !isNull(InteractionDate) && !isNull(InteractionType),
	disjoint: false) ~> ValidateColumns@(CleanData, QuarantineData)
ValidateColumns@CleanData derive(InteractionType = case(
  upper(InteractionType) == 'ERR', 'Error',
  upper(InteractionType) == 'CMP', 'Complaint',
  upper(InteractionType) == 'ENQ', 'Enquiry',
  InteractionType
),
		InteractionID = toString(InteractionID),
		IngestionTimestamp = currentTimestamp()) ~> StandardizeInteractions
ValidateColumns@QuarantineData sink(allowSchemaDrift: true,
	validateSchema: false,
	umask: 0022,
	preCommands: [],
	postCommands: [],
	skipDuplicateMapInputs: true,
	skipDuplicateMapOutputs: true) ~> sink1
StandardizeInteractions sink(allowSchemaDrift: true,
	validateSchema: false,
	umask: 0022,
	preCommands: [],
	postCommands: [],
	skipDuplicateMapInputs: true,
	skipDuplicateMapOutputs: true) ~> sink2