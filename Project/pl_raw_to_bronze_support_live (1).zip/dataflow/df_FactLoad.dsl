source(output(
		CustomerSK as integer,
		CustomerID as string,
		ContractID as string,
		CustomerName as string,
		Age as integer,
		Gender as string,
		Region as string,
		Address as string,
		TenureMonths as integer,
		TenureBand as string,
		EffectiveStartDate as date,
		EffectiveEndDate as date,
		IsCurrent as boolean
	),
	allowSchemaDrift: true,
	validateSchema: false,
	isolationLevel: 'READ_UNCOMMITTED',
	format: 'table') ~> DimCustomer
source(output(
		BillingID as string,
		CustomerID as string,
		ContractID as string,
		BillMonth as date,
		BillAmount_GBP as decimal(10,2),
		PaymentStatus as string,
		DaysDelayed as integer,
		Penalty as decimal(10,2),
		PaymentRiskCategory as string
	),
	allowSchemaDrift: true,
	validateSchema: false,
	isolationLevel: 'READ_UNCOMMITTED',
	format: 'table') ~> BillingPayment
source(output(
		InteractionID as string,
		CustomerID as string,
		InteractionDate as date,
		InteractionType as string,
		BronzeTimestamp as timestamp,
		IngestionTimestamp as timestamp
	),
	allowSchemaDrift: true,
	validateSchema: false,
	isolationLevel: 'READ_UNCOMMITTED',
	format: 'table') ~> CustomerInteraction
source(output(
		UsageID as string,
		CustomerID as string,
		Month as string,
		UnitsConsumed_kWh as integer,
		ingestion_timestamp as timestamp,
		BronzeTimestamp as timestamp,
		Month_name as string
	),
	allowSchemaDrift: true,
	validateSchema: false,
	isolationLevel: 'READ_UNCOMMITTED',
	format: 'table') ~> EnergyUsage
source(output(
		CustomerID as string,
		CustomerName as string,
		Age as string,
		Gender as string,
		Region as string,
		ContractMonths as string,
		ContractID as string,
		Address as string,
		Tariff_Name as string,
		Contract_start_date as string,
		BronzeTimestamp as string,
		Contract_end_date as string,
		TenureMonths as string,
		TenureBand as string,
		ContractStatus as string,
		EnergyPriceIndex as string,
		VolatilityLevel as string,
		RiskCategory as string,
		Factor as string
	),
	allowSchemaDrift: true,
	validateSchema: false,
	ignoreNoFilesFound: false) ~> CustomerMaster
DimCustomer filter(IsCurrent==true()) ~> ActiveRecords
CustomerInteraction aggregate(groupBy(CustomerID),
	ComplaintCount = count(InteractionType=='Complaint'),
		ServiceInteractionCount = count(InteractionType)) ~> aggregate2
BillingPayment window(over(CustomerID),
	asc(BillMonth, true),
	PrevBill = lag(BillAmount_GBP)) ~> window1
derivedColumn2 aggregate(groupBy(CustomerID),
	AvgBillTrend = avg(BillChangePct),
		AvgBillAmount_GBP = avg(BillAmount_GBP)) ~> aggregate3
window1 derive(BillChangePct = iif(isNull(PrevBill),0.0,(toFloat(BillAmount_GBP)-toFloat(PrevBill))/toFloat(PrevBill)*100.0)) ~> derivedColumn2
BillingPayment derive(LateFlag = iif(DaysDelayed>0,1,0)) ~> derivedColumn3
derivedColumn3 aggregate(groupBy(CustomerID),
	LatePayementCount = sum(LateFlag)) ~> aggregate4
EnergyUsage aggregate(groupBy(CustomerID),
	UsageVariability = stddev(UnitsConsumed_kWh),
		AvgUsage = avg(UnitsConsumed_kWh),
		MaxUsage = max(UnitsConsumed_kWh),
		TotalUsage = sum(UnitsConsumed_kWh)) ~> aggregate5
aggregate5 derive(AbnormalFlag = iif(MaxUsage>(AvgUsage+1.5*UsageVariability),'YES','NO')) ~> derivedColumn4
CustomerMaster derive(ContractExpiryRisk = iif(toDate(Contract_end_date)<=subDays(currentDate(),-30),1,0),
		TenureRisk = iif(toInteger(TenureMonths)>18,0,1),
		MarketVolatalityRisk = iif(RiskCategory=='High',1,0)) ~> derivedColumn5
aggregate3 derive(BillPaymentRisk = iif(AvgBillTrend>0,1,0)) ~> derivedColumn6
aggregate4 derive(LatePayementRisk = iif(LatePayementCount>1,1,0)) ~> derivedColumn7
aggregate2 derive(ComplaintRisk = iif(ComplaintCount>1,1,0)) ~> derivedColumn8
derivedColumn6, derivedColumn7 join(aggregate3@CustomerID == aggregate4@CustomerID,
	joinType:'left',
	matchType:'exact',
	ignoreSpaces: false,
	broadcast: 'auto')~> join1
join1, ActiveRecords join(aggregate3@CustomerID == DimCustomer@CustomerID,
	joinType:'left',
	matchType:'exact',
	ignoreSpaces: false,
	broadcast: 'auto')~> join2
derivedColumn8, ActiveRecords join(aggregate2@CustomerID == DimCustomer@CustomerID,
	joinType:'left',
	matchType:'exact',
	ignoreSpaces: false,
	broadcast: 'auto')~> join3
derivedColumn4, ActiveRecords join(aggregate5@CustomerID == DimCustomer@CustomerID,
	joinType:'left',
	matchType:'exact',
	ignoreSpaces: false,
	broadcast: 'auto')~> join4
derivedColumn5, derivedColumn6 join(CustomerMaster@CustomerID == aggregate3@CustomerID,
	joinType:'left',
	matchType:'exact',
	ignoreSpaces: false,
	broadcast: 'auto')~> join7
join7, derivedColumn7 join(CustomerMaster@CustomerID == aggregate4@CustomerID,
	joinType:'left',
	matchType:'exact',
	ignoreSpaces: false,
	broadcast: 'auto')~> join8
join8, derivedColumn8 join(CustomerMaster@CustomerID == aggregate2@CustomerID,
	joinType:'left',
	matchType:'exact',
	ignoreSpaces: false,
	broadcast: 'auto')~> join9
join9, derivedColumn4 join(CustomerMaster@CustomerID == aggregate5@CustomerID,
	joinType:'left',
	matchType:'exact',
	ignoreSpaces: false,
	broadcast: 'auto')~> join10
join10 derive(ChurnScore = 25*ContractExpiryRisk+20*BillPaymentRisk+30*LatePayementRisk+25*ComplaintRisk+20*MarketVolatalityRisk-30*TenureRisk) ~> derivedColumn9
derivedColumn9 derive(LoyaltyScore = 100-ChurnScore) ~> derivedColumn10
derivedColumn10, ActiveRecords join(CustomerMaster@CustomerID == DimCustomer@CustomerID,
	joinType:'left',
	matchType:'exact',
	ignoreSpaces: false,
	broadcast: 'auto')~> join11
join2 alterRow(upsertIf(1==1)) ~> AlterRow1
join4 alterRow(upsertIf(1==1)) ~> AlterRow2
join11 alterRow(upsertIf(1==1)) ~> AlterRow3
join3 alterRow(upsertIf(1==1)) ~> AlterRow4
AlterRow1 sink(allowSchemaDrift: true,
	validateSchema: false,
	input(
		CustomerSK as integer,
		AvgBillTrend as decimal(10,2),
		AvgBillAmount_GBP as decimal(10,2),
		LatePaymentCount as integer
	),
	deletable:false,
	insertable:true,
	updateable:false,
	upsertable:true,
	keys:['CustomerSK'],
	format: 'table',
	skipDuplicateMapInputs: true,
	skipDuplicateMapOutputs: true,
	errorHandlingOption: 'stopOnFirstError',
	mapColumn(
		CustomerSK,
		AvgBillTrend,
		AvgBillAmount_GBP,
		LatePaymentCount = LatePayementCount
	)) ~> sink5
AlterRow2 sink(allowSchemaDrift: true,
	validateSchema: false,
	input(
		CustomerSK as integer,
		AvgUnitsConsumed as decimal(10,2),
		UsageVariability as decimal(10,2),
		TotalUsage as integer,
		AbnormalFlag as string
	),
	deletable:false,
	insertable:true,
	updateable:false,
	upsertable:true,
	keys:['CustomerSK'],
	format: 'table',
	skipDuplicateMapInputs: true,
	skipDuplicateMapOutputs: true,
	errorHandlingOption: 'stopOnFirstError',
	mapColumn(
		CustomerSK,
		AvgUnitsConsumed = AvgUsage,
		UsageVariability,
		TotalUsage,
		AbnormalFlag
	)) ~> sink6
AlterRow3 sink(allowSchemaDrift: true,
	validateSchema: false,
	input(
		CustomerSK as integer,
		CustomerID as string,
		ChurnScore as integer,
		LoyaltyScore as integer,
		RiskBand as string,
		ScoreDate as timestamp
	),
	deletable:false,
	insertable:true,
	updateable:false,
	upsertable:true,
	keys:['CustomerSK'],
	format: 'table',
	skipDuplicateMapInputs: true,
	skipDuplicateMapOutputs: true,
	errorHandlingOption: 'stopOnFirstError',
	mapColumn(
		CustomerSK,
		CustomerID = CustomerMaster@CustomerID,
		ChurnScore,
		LoyaltyScore,
		RiskBand = RiskCategory,
		ScoreDate = EffectiveStartDate
	)) ~> sink7
AlterRow4 sink(allowSchemaDrift: true,
	validateSchema: false,
	input(
		CustomerSK as integer,
		ComplaintCount as integer,
		ServiceInteractionCount as integer
	),
	deletable:false,
	insertable:true,
	updateable:false,
	upsertable:true,
	keys:['CustomerSK'],
	format: 'table',
	skipDuplicateMapInputs: true,
	skipDuplicateMapOutputs: true,
	errorHandlingOption: 'stopOnFirstError',
	mapColumn(
		CustomerSK,
		ComplaintCount,
		ServiceInteractionCount
	)) ~> sink8