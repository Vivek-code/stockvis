source(output(
		CustomerID as string,
		CustomerName as string,
		Age as string,
		Gender as string,
		Region as string,
		ContractMonths as string,
		ContractID as string,
		Address as string,
		Tariff_Name as string,
		Contract_start_date as string,
		BronzeTimestamp as string
	),
	allowSchemaDrift: true,
	validateSchema: false,
	ignoreNoFilesFound: false) ~> customermaster
source(output(
		MarketID as string,
		Date as string,
		Region as string,
		EnergyPriceIndex as string,
		VolatilityLevel as string,
		RiskCategory as string,
		Factor as string
	),
	allowSchemaDrift: true,
	validateSchema: false,
	ignoreNoFilesFound: false) ~> externalmarket
split1@valid derive(Gender = upper(Gender),
		Tariff_Name = trim(Tariff_Name),
		Region = trim(Region),
		CustomerName = initCap(trim(CustomerName))) ~> generaltransforms
generaltransforms derive(Contract_end_date = toString(addMonths(toDate(Contract_start_date, 'dd-MM-yyyy'), toInteger(ContractMonths)), 'dd-MM-yyyy')) ~> contractEdTenMonths
customermaster split(!isNull(CustomerID) && !isNull(CustomerName) && !isNull(ContractID),
	disjoint: false) ~> split1@(valid, invalid)
TenureMonths derive(TenureBand = iif(toInteger(TenureMonths) < 6, 'Low', iif(toInteger(TenureMonths) <= 12, 'Medium', 'High')),
		ContractStatus = iif(currentDate() > toDate(Contract_end_date,'dd-MM-yyyy'), 'Inactive', 'Active')) ~> tenureAndStatus
tenureAndStatus, externalmarket join(generaltransforms@Region == externalmarket@Region,
	joinType:'inner',
	matchType:'exact',
	ignoreSpaces: false,
	broadcast: 'auto')~> join1
contractEdTenMonths derive(TenureMonths = iif(
  toDate(Contract_end_date, 'dd-MM-yyyy') <= currentDate(),
  ContractMonths,
  toString(round(monthsBetween(currentDate(), toDate(Contract_start_date, 'dd-MM-yyyy'))))
)) ~> TenureMonths
join1 select(mapColumn(
		CustomerID,
		CustomerName,
		Age,
		Gender,
		Region = generaltransforms@Region,
		ContractMonths,
		ContractID,
		Address,
		Tariff_Name,
		Contract_start_date,
		BronzeTimestamp,
		Contract_end_date,
		TenureMonths,
		TenureBand,
		ContractStatus,
		EnergyPriceIndex,
		VolatilityLevel,
		RiskCategory,
		Factor
	),
	skipDuplicateMapInputs: true,
	skipDuplicateMapOutputs: true) ~> select1
select1 sink(allowSchemaDrift: true,
	validateSchema: false,
	input(
		BillingID as string,
		CustomerID as string,
		ContractID as string,
		BillMonth as string,
		BillAmount_GBP as string,
		PaymentStatus as string,
		DaysDelayed as string,
		ingestion_timestamp as string
	),
	umask: 0022,
	preCommands: [],
	postCommands: [],
	skipDuplicateMapInputs: true,
	skipDuplicateMapOutputs: true) ~> customermastersink
split1@invalid sink(allowSchemaDrift: true,
	validateSchema: false,
	input(
		BillingID as string,
		CustomerID as string,
		ContractID as string,
		BillMonth as string,
		BillAmount_GBP as string,
		PaymentStatus as string,
		DaysDelayed as string,
		IngestionTimestamp as string
	),
	umask: 0022,
	preCommands: [],
	postCommands: [],
	skipDuplicateMapInputs: true,
	skipDuplicateMapOutputs: true) ~> quarantinesink