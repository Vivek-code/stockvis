source(output(
		BillingID as string,
		CustomerID as string,
		ContractID as string,
		BillMonth as string,
		BillAmount_GBP as string,
		PaymentStatus as string,
		DaysDelayed as string,
		penalty as string,
		PaymentRiskCategory as string
	),
	allowSchemaDrift: true,
	validateSchema: false,
	ignoreNoFilesFound: false) ~> BillingPayment
source(output(
		ContractSK as integer,
		CustomerID as string,
		ContractID as string,
		TariffName as string,
		Contract_start_date as date,
		Contract_end_date as date,
		ContractStatus as string,
		EffectiveStartDate as date,
		EffectiveEndDate as date,
		IsCurrent as boolean
	),
	allowSchemaDrift: true,
	validateSchema: false,
	isolationLevel: 'READ_UNCOMMITTED',
	format: 'table') ~> ExistingDimCustomer
source(output(
		CustomerID as string,
		CustomerName as string,
		Age as string,
		Gender as string,
		Region as string,
		TenureMonths as string,
		TenureStatus as string,
		ContractID as string,
		Address as string,
		Tariff_Name as string,
		Contract_start_date as string,
		IngestionTimestamp as string,
		Contract_end_date as string,
		ContractStatus as string
	),
	allowSchemaDrift: true,
	validateSchema: false,
	ignoreNoFilesFound: false) ~> CustomerMaster
Silver, ActiveRecords join(CustomerID_Silver == CustomerID
	&& ContractID_Silver == ContractID,
	joinType:'left',
	matchType:'exact',
	ignoreSpaces: false,
	broadcast: 'auto')~> join1
join2 select(mapColumn(
		CustomerID_Silver = CustomerMaster@CustomerID,
		ContractID_Silver = BillingPayment@ContractID,
		Tariff_Name_Silver = Tariff_Name,
		Contract_start_date_Silver = Contract_start_date,
		Contract_end_date_Silver = Contract_end_date,
		ContractStatus_Silver = ContractStatus
	),
	skipDuplicateMapInputs: true,
	skipDuplicateMapOutputs: true) ~> Silver
ExistingDimCustomer filter(IsCurrent == true()) ~> ActiveRecords
select1 derive(isChanged = !isNull(ContractSK_Dim) && (Tariff_Name_Silver!=TariffName_Dim || ContractStatus_Silver!=ContractStatus_Dim)) ~> derivedColumn1
derivedColumn1 split(isNull(ContractSK_Dim),
	isChanged==true(),
	disjoint: false) ~> split1@(New, Changed, Unchanged)
split1@New derive(EffectiveStartDate = currentDate(),
		IsCurrent = true(),
		EffectiveEndDate = toDate('9999-12-31', 'yyyy-MM-dd')) ~> derivedColumn2
split1@Changed derive(EffectiveStartDate = currentDate(),
		IsCurrent = true(),
		insertFlag = true(),
		EffectiveEndDate = toDate("9999-12-31","yyyy-MM-dd")) ~> derivedColumn3
split1@Changed derive(EffectiveEndDate = currentDate(),
		IsCurrent = false(),
		updateFlag = true()) ~> derivedColumn4
derivedColumn4 alterRow(updateIf(updateFlag)) ~> alterRow1
join1 select(mapColumn(
		CustomerID_Silver,
		ContractID_Silver,
		Tariff_Name_Silver,
		Contract_start_date_Silver,
		Contract_end_date_Silver,
		ContractStatus_Silver,
		ContractSK_Dim = ContractSK,
		CustomerID_Dim = CustomerID,
		ContractID_Dim = ContractID,
		TariffName_Dim = TariffName,
		Contract_start_date_Dim = Contract_start_date,
		Contract_end_date_Dim = Contract_end_date,
		ContractStatus_Dim = ContractStatus,
		EffectiveStartDate,
		EffectiveEndDate,
		IsCurrent
	),
	skipDuplicateMapInputs: true,
	skipDuplicateMapOutputs: true) ~> select1
derivedColumn3 alterRow(insertIf(insertFlag)) ~> alterRow2
derivedColumn2 alterRow(insertIf(true())) ~> alterRow3
BillingPayment, CustomerMaster join(BillingPayment@CustomerID == CustomerMaster@CustomerID,
	joinType:'right',
	matchType:'exact',
	ignoreSpaces: false,
	broadcast: 'auto')~> join2
alterRow1 sink(allowSchemaDrift: true,
	validateSchema: false,
	input(
		ContractSK as integer,
		CustomerID as string,
		ContractID as string,
		TariffName as string,
		Contract_start_date as string,
		Contract_end_date as string,
		ContractStatus as string,
		EffectiveStartDate as date,
		EffectiveEndDate as date,
		IsCurrent as boolean
	),
	deletable:false,
	insertable:false,
	updateable:true,
	upsertable:false,
	keys:['ContractSK'],
	format: 'table',
	skipDuplicateMapInputs: true,
	skipDuplicateMapOutputs: true,
	errorHandlingOption: 'stopOnFirstError',
	mapColumn(
		CustomerID = CustomerID_Silver,
		ContractID = ContractID_Silver,
		TariffName = Tariff_Name_Silver,
		Contract_start_date = Contract_start_date_Silver,
		Contract_end_date = Contract_end_date_Silver,
		ContractStatus = ContractStatus_Silver,
		EffectiveStartDate,
		EffectiveEndDate,
		IsCurrent,
		ContractSK = ContractSK_Dim
	)) ~> oldRecords
alterRow2 sink(allowSchemaDrift: true,
	validateSchema: false,
	input(
		ContractSK as integer,
		CustomerID as string,
		ContractID as string,
		TariffName as string,
		Contract_start_date as string,
		Contract_end_date as string,
		ContractStatus as string,
		EffectiveStartDate as date,
		EffectiveEndDate as date,
		IsCurrent as boolean
	),
	deletable:false,
	insertable:true,
	updateable:false,
	upsertable:false,
	format: 'table',
	skipDuplicateMapInputs: true,
	skipDuplicateMapOutputs: true,
	errorHandlingOption: 'stopOnFirstError',
	mapColumn(
		CustomerID = CustomerID_Silver,
		ContractID = ContractID_Silver,
		TariffName = Tariff_Name_Silver,
		Contract_start_date = Contract_start_date_Silver,
		Contract_end_date = Contract_end_date_Silver,
		ContractStatus = ContractStatus_Silver,
		EffectiveStartDate,
		EffectiveEndDate,
		IsCurrent
	)) ~> changedRecords
alterRow3 sink(allowSchemaDrift: true,
	validateSchema: false,
	input(
		ContractSK as integer,
		CustomerID as string,
		ContractID as string,
		TariffName as string,
		Contract_start_date as string,
		Contract_end_date as string,
		ContractStatus as string,
		EffectiveStartDate as date,
		EffectiveEndDate as date,
		IsCurrent as boolean
	),
	deletable:false,
	insertable:true,
	updateable:false,
	upsertable:false,
	format: 'table',
	skipDuplicateMapInputs: true,
	skipDuplicateMapOutputs: true,
	errorHandlingOption: 'stopOnFirstError',
	mapColumn(
		CustomerID = CustomerID_Silver,
		ContractID = ContractID_Silver,
		TariffName = Tariff_Name_Silver,
		Contract_start_date = Contract_start_date_Silver,
		Contract_end_date = Contract_end_date_Silver,
		ContractStatus = ContractStatus_Silver,
		EffectiveStartDate,
		EffectiveEndDate,
		IsCurrent
	)) ~> newRecords